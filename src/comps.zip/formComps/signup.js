import React from 'react';

function SignUp(props) {
  return (
    <div>
      <form>
      <div className="mb-3">
          <label htmlFor="name" className="form-label">Name</label>
          <input name="name" type="password" className="form-control" id="name" />
        </div>
        <div className="mb-3">
        <label htmlFor="email" className="form-label">Email</label>
          <input name="email" type="text" className="form-control" id="email" />

        </div>
        <div className="mb-3">
        <label htmlFor="pass" className="form-label">Password</label>
          <input name="pass" type="password" className="form-control" id="pass" />

        </div>
       

        <button type="submit" className="btn btn-primary">Submit</button>
      </form>

    </div>
  )
}

export default SignUp