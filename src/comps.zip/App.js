import './App.css';
import AppToDo from './comps_hw_todo/appTodo';
import AppForm from './formComps/appForm';

function App() {
  return (
    <div className="App">
      <AppForm />
      {/* <AppToDo /> */}
    </div>
  );
}

export default App;
